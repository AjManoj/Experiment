 (function() { 
        var app=angular.module('StandardAngular',['StandardAngularInitilizer','ngAnimate','angularUtils.directives.dirPagination','ngSanitize','ui.bootstrap'])//,'cometd-reload'
        app.factory('blocks',function(){
			var Block=function(blockParams){
				fromJson(this,blockParams)
			}
			var fromJson = function(thisobject, jsonobject) {  
              for (var prop in jsonobject) {
                if (jsonobject.hasOwnProperty(prop)) {
                  thisobject[prop] = jsonobject[prop];      
                }
              }
            };
			return {
                getNewBlock:function(blockParams){
                    return new Block(blockParams)
                }

            }
		})
		app.factory('jsonListOfObjectDefination',function($salesforceApiForVf,$rootScope,$q){
            
            var jsonListOfObjectDefination=window.jsonListOfObjectDefination||{}
            jsonListOfObjectDefination.addObjectDefination=function(data) {
                var deferred = $q.defer();
                Visualforce.remoting.Manager.invokeAction(
                    'StandardAngularController.getMapOfObjectDefinationFromfunctionRemote',
                    data,
                    function(result, event) {
                        $rootScope.$apply(function() {
                            if (event.status) {
                                deferred.resolve(result);
                                fromJson(jsonListOfObjectDefination,JSON.parse(result))
                            } else {
                                deferred.reject(event);
                            }
                        })
                    },
                    { buffer: true, escape: false, timeout:  120000 }
                );
                return deferred.promise;
            }
            jsonListOfObjectDefination.addObjectDefinationApi=function(data) {
                    
            }
                
            var fromJson = function(thisobject, jsonobject) {  
              for (var prop in jsonobject) {
                if (jsonobject.hasOwnProperty(prop)) {
                  thisobject[prop] = jsonobject[prop];      
                }
              }
            };
           
            return jsonListOfObjectDefination;
        })
        app.factory('SbojectConstruction',function(extractRowMetadata,jsonListOfObjectDefination,$salesforceApiForVf){
            var SbojectConstruction=this
			            
            var SobjectWrapperNew =function(SobjectWrapperParameters,calls){
                if(!SobjectWrapperParameters)
                {
                    console.log('Atleast provide type of object as "Key"')
                    return 
                }
                fromJson(this,SobjectWrapperParameters)
                this.UniqueiId=SobjectWrapperParameters['UniqueiId'];
                if(SobjectWrapperParameters['objectName'])
                    this.Key=SobjectWrapperParameters['objectName'];
                else
                    this.Key=SobjectWrapperParameters['Key'];
                this.Label=SobjectWrapperParameters['Label'];
                this.Name=SobjectWrapperParameters['Name'];
                this.Filters=SobjectWrapperParameters['Filters']||[];
                this.Fields=SobjectWrapperParameters['Fields']||[];
                this.filterExpresion=SobjectWrapperParameters['filterExpresion']||'1';
                this.filterExpressionPreProcessor=SobjectWrapperParameters['filterExpressionPreProcessor']||{}
                this.validations=SobjectWrapperParameters['filterExpressionPreProcessor']||{}
                this.displayFields=SobjectWrapperParameters['displayFields']||[];
                this.displayColums=SobjectWrapperParameters['displayColums']||[];
                
                this.RelatedListMap=SobjectWrapperParameters['RelatedListMap']||[];
                this.lookupViewDefination=SobjectWrapperParameters['lookupViewDefination']||{};
                this.NewViewDefination=SobjectWrapperParameters['NewViewDefination']||angular.copy(this);
                this.actionButtons=SobjectWrapperParameters['actionButtons']||[]
                
                var wherepart='';
                if(this.Filters&&this.Filters.length>0){
                    if(this.filterExpresion==null)
                        wherepart=' where '+joinFilters(this.Filters,'1');
                    else{
                       wherepart=' where '+joinFilters(this.Filters,this.filterExpresion); 
                    }
                }
                if(this.Fields)
                this.query='Select '+this.Fields.join(',')+' From '+this.Key+wherepart;
                this.recentQuery='SELECT '+this.Fields.join(',')+' RecentlyViewed WHERE Type IN (\''+this.Key+'\') ORDER BY LastViewedDate DESC ';
                if(this.Fields&&this.Fields.indexOf('Id')>-1)
                    this.searchQuery='Find {} In Name FIELDS RETURNING '+this.Key+' ('+this.Fields.join(',')+wherepart+' limit 100)';
                    //this.evalSearchQuery='this.searchQuery=this.searchQuery.replace( /({)(.*?)(})/, "{*some string*}" );'
                else if(this.Fields!=null&&this.Fields.indexOf('Id')==-1){
                    this.searchQuery='Find {} In Name FIELDS RETURNING '+this.Key+' (Id,'+this.Fields.join(',')+wherepart+'  limit 100)';    
                }
                
                
                if(jsonListOfObjectDefination[this.Key]&&jsonListOfObjectDefination[this.Key].masterrecordId)
                    this.layoutLink=jsonListOfObjectDefination[this.Key].RecordTypeInfosById[jsonListOfObjectDefination[this.Key].masterrecordId].urls.layout
                else if(jsonListOfObjectDefination[this.Key])
                	this.layoutLink="/services/data/v40.0/sobjects/"+this.Key+"/describe/layouts/@{dataquery.records[0].RecordTypeId}"
                
                this.fetchQuery=fetchQuery
                this.reload=fetchQuery
                this.fetchDataUrl=fetchDataUrl
                this.fetchQueryInit=fetchQueryInit
                this.processRealtedList=processRealtedList
                this.promises={}
                if(calls&&calls instanceof Array){
                    calls.forEach(function(call){
                        this.promises[call]=this[call]()
                    }.bind(this))
                    
                }else if(calls){
                    this.promises[calls]=this[calls]()
                }
                this.processQuery=function(filterValue,generatedQuery){
                    if(!generatedQuery)
                    	generatedQuery={}
                    generatedQuery.searchQuery=this.searchQuery.replace( /({)(.*?)(})/, "{"+filterValue+"}" )
                    generatedQuery.query=this.query
                    if(this.filterExpressionPreProcessor)
                    for (filterName in this.filterExpressionPreProcessor) {
                         if (this.filterExpressionPreProcessor.hasOwnProperty(filterName)) {
                              if(this.filterExpressionPreProcessor[filterName]){
                              	generatedQuery.searchQuery=generatedQuery.searchQuery.replace( new RegExp('({)'+filterName+'(})'), this.filterExpressionPreProcessor[filterName])
                              	generatedQuery.query=generatedQuery.query.replace( new RegExp('({)'+filterName+'(})'), this.filterExpressionPreProcessor[filterName])
                              }esle{
                                  
                              }
                          }
                    }
                    return generatedQuery;
                }
                this.validate=function(name,value,value2,id){
                    if(!id)
                        id=0
                    if(!value&&this.updatedvalues)
                        value=this.updatedvalues[id]
                    if(!value2)
                        value2=this.data[id]
                    if(name&&this.validations[name]){
                        
                       return this.validations[name].validated=((this.value&&this.value[name]==true)||(this.value2&&this.value2[prop]==true))
                       // return eval(this.validations[name].expressionthis.searchQuery.replace( /({)(.*?)(})/g, "'"+value[name]+"'")
                    }else{
                        for (var prop in this.validations) {
                            if (this.validations.hasOwnProperty(prop)) {
                                if(this.validations[prop]){
                                    return this.validations[prop].validated=((this.value&&this.value[name]==true)||(this.value2&&this.value2[prop]==true))
                                    break;
                                }
                            }
                            return false
                        }
                    }
                }.bind(this)
    			console.log(this)
            }
            var joinFilters=function(Filters,filterExpresion){
                var filterExpresionsplitted= filterExpresion.split('');
                
                for(var i=0;i<filterExpresionsplitted.length;i++){
                    try{
                    	if(Filters[parseInt(filterExpresionsplitted[i])-1])                  
                        	filterExpresionsplitted[i]=Filters[parseInt(filterExpresionsplitted[i])-1];
                    }catch(e){
                        
                    }
                }
                return  filterExpresionsplitted.join('') ;               
            }
            
            var displayField=function(displayFieldParameters){
                            this.LabelName=displayFieldParameters.LabelName
                            this.apiName=displayFieldParameters.apiName
                            this.controller=displayFieldParameters.controller
                            this.editable=displayFieldParameters.editable
                            this.typeoffield=displayFieldParameters.typeoffield
                            this.template=displayFieldParameters.template
							if(this.controller==null)
								this.controller=this.typeoffield;
							if(this.template==null)
								this.template=this.typeoffield;
                        }
            var actionButton=function(actionButtonParameters){
                            this.label=actionButtonParameters.label
                            this.name=actionButtonParameters.name
                        }
            var prototype=function(displayFields,key,defaultValues){
                var prototype=this
                displayFields.forEach(function(v) {
                     var metadata=extractRowMetadata(key,v.apiName)
                     var property=metadata.relationshipName||metadata.name
                     if(defaultValues[property])
                        prototype[property]=defaultValues[property]
                     else
                     	prototype[property]=undefined;
                })
                prototype['sobjectType']=key
                this.getRelationShipName=function(parentkey,childkey){
                    var relationshipName
                    if(jsonListOfObjectDefination[parentkey])
                        jsonListOfObjectDefination[parentkey].ChildRelationship.forEach(function(v){
                            if(childkey==v.childSObject){
								  if(jsonListOfObjectDefination[childkey])
									relationshipName=jsonListOfObjectDefination[childkey].fieldDescribeMap[v.field].relationshipName
								  else
									console.error('Metdata not available'+childkey+' for '+relationshipName+'')  
							}	  
                        })
                    else
                        console.log('Object defeination not available')
                    return relationshipName
                    
                }
                this.postData=function(data,updatedValues,k){
                    var v=angular.copy(data)
                    
                    if(updatedValues[k])
                    for (var prop in updatedValues[k]) {
                              if (updatedValues[k].hasOwnProperty(prop)) {
                                  
                                  v[prop] = updatedValues[k][prop];  
                                      
                              }
                          }
                    
                    for (var prop in v){
                          		  var md=extractRowMetadata(this['sobjectType'],prop)
                                  if(md&&md.relationshipName){
                                    if(updatedValues[k]&&updatedValues[k][prop])
                                  	v[md.name] = updatedValues[k][prop]
                                    
                                    if(v[prop]&&!v[md.name])
                                    	v[md.name] =v[prop].Id;
                                    delete v[md.relationshipName]
                                  }
                      	  }
					
                    delete v.Id
                     
                    return v
                }
                
            }          
            var fromJson = function(thisobject, jsonobject) {  
              for (var prop in jsonobject) {
                if (jsonobject.hasOwnProperty(prop)) {
                  thisobject[prop] = jsonobject[prop];      
                }
              }
            }; 
            var fetchQueryInit=function(org){
                this.data=[]
                var compositefunction=$salesforceApiForVf.composite
                return compositefunction(
                    org||this.org||$salesforceApiForVf.org,
                    {
                       query:{soql:this.query,referenceId:'dataquery'},
                       fetchUrl:{pathplusquery:this.layoutLink, referenceId:"layoutdata"}
                    }
                ).then(
                        function(response){
                            this.data=response.data.compositeResponse[0].body.records
                            this.layout=response.data.compositeResponse[1].body
                            this.layout.relatedListsMap={}
                            if(this.layout.relatedLists)
                            this.layout.relatedLists.forEach(function(value,key){
                                this.layout.relatedListsMap[value.sobject]=value
                            }.bind(this))
							if(this.promises['processsLayout']){
								this.promises['fetchQueryInit'].startProcessLayout=true
								return processsLayout(org)
							}	
                        }.bind(this),
                    	function(response){
                        
                        }.bind(this)
                 )
                 
            }
            var fetchDataUrl=function(org){
                this.data=[]
                var fetchUrl=$salesforceApiForVf.fetchUrl
            	return fetchUrl(org||this.org||$salesforceApiForVf.org,this.dataUrl).then(
                        function(response){
                            this.data=[]
                            this.data.push(response.data)
                            
                        }.bind(this),null,
                        function(response){
                            
                        }.bind(this)
                    )
            }
            var fetchQuery=function(org){
                this.data=[]
                var queryfunction=$salesforceApiForVf.query
                if(this.tooling)
                    queryfunction=$salesforceApiForVf.toolingquery
            	return queryfunction(org||this.org||$salesforceApiForVf.org,this.query).then(
                        function(response){
                            this.data=response.data.records
                            this.totallength=response.data.totalSize
                            
                        }.bind(this),null,
                        function(response){
                            this.data=response.data.records
                            this.totallength=response.data.totalSize
                        }.bind(this)
                    )
            }
            
            var processsLayout=function(org){
				if(!this.promises['fetchQueryInit'].startProcessLayout)
					return true
                var ObjectDefination=[]
                if(!this.displayFields){
                    this.displayFields=[]
                    if(!this.Fields&&layout.detailLayoutSections)
                        this.Fields=[]
                    this.detailLayoutSections.forEach(function(section){
                        section.layoutRows.forEach(function(row){
                            row.layoutItems.forEach(function(item){
                                var type,value
                                if(item.layoutComponents[0]&&item.layoutComponents[0].details){
                                    if(item.layoutComponents[0].details.type=="reference"){
                                    	type='LOOKUP';
                                        value=item.layoutComponents[0].details.relationshipName+".Name";
                                        
                                        this.Fields.push(value)
                                        this.Fields.push(item.layoutComponents[0].details.relationshipName+".Id")
                                    }else{
                                    	type=item.layoutComponents[0].details.type;
                                        value=item.layoutComponents[0].value;
                                        this.Fields.push(value)
                                    }
                                }
                                
                                if(item.layoutComponents[0]&&item.layoutComponents[0].details){
                                    this.displayFields.push(SbojectConstruction.getDisplayfieldNew({
                                        LabelName:item.label,
                                        apiName:item.layoutComponents[0].value,
                                        editable:item.layoutComponents[0].details.updateable,
                                        typeoffield:type,
                                        controller:type,
                                        template:type,
                                    }))
                                }
                                else if(item.layoutComponents[0]&&item.layoutComponents[0].type)
                                    this.displayFields.push(SbojectConstruction.getDisplayfieldNew({
                                    LabelName:item.label,
                                    apiName:item.layoutComponents[0].value,
                                    editable:false,
                                    typeoffield:type,
                                    template:type,
                                   	controller:type
                                }))
                                //else
                                    //debugger;
                            }.bind(this))
                        }.bind(this))
                    }.bind(this))
                }
                if(this.layout.relatedLists){
                    this.RelatedListMap=[]
                    this.layout.relatedLists.forEach(function(relatedList){
                        ObjectDefination.push(relatedList.sobject)
                        
                        var newrlatedlist={'Key':relatedList.sobject,
                                           'Name':relatedList.label,
                                           'Filters':[relatedList.field+"='"+this.data[0].Id+"'"],
                                           'Fields':[],
                                           displayColums:[]
                                          }
                        relatedList.columns.forEach(function(column){
                            if(column.lookupId&&column.lookupId!='Name'){
                                type='LOOKUP';
                                value=column.fieldApiName;
                                        
                                newrlatedlist.Fields.push(column.lookupId)
                                if(column.lookupId.indexOf('.Name')>0)
                                newrlatedlist.Fields.push(column.lookupId.replace('.Name','.Id'))
                                newrlatedlist.Fields.push(value)
                           }else{
                                type="STRING";
                                value=column.fieldApiName;
                                newrlatedlist.Fields.push(column.fieldApiName)
                           }
                           newrlatedlist.displayColums.push(SbojectConstruction.getDisplayfieldNew({
                                        LabelName:column.label,
                                        apiName:column.fieldApiName,
                                        editable:false,
                                        typeoffield:type,
                                        controller:type,
                                        template:type,
                                    }))
                        })          
                        this.RelatedListMap.push(SbojectConstruction.getSbojectWrapperNew(newrlatedlist))
                    }.bind(this))
                }
                return jsonListOfObjectDefination.addObjectDefination(ObjectDefination)               
                
                console.log('layout fetched')
            }.bind(this)
            
            var processRealtedList=function(){
                if(this.RelatedListMap){
                    this.RelatedListMap.forEach(function(v){
                        SbojectConstruction.getSbojectWrapperNew(v)
                    })
                }
                
            }
            
            return {
                getSbojectWrapperNew:function(SobjectWrapperParameters,callfetchQuery){
                    return new SobjectWrapperNew(SobjectWrapperParameters,callfetchQuery)
                },
                getActionButtonNew:function(actionButtonParameters){
                    return new actionButton(actionButtonParameters)
                },
                getDisplayfieldNew:function(displayFieldParameters){
                    return new displayField(displayFieldParameters)
                },
                getPrototypeNew:function(displayFields,key,defaultValues){
                    return new prototype(displayFields,key,defaultValues)
                }
            }
        })
        app.factory('Sboject',function($q,$salesforceApiForVf,$rootScope,SbojectConstruction,Object_ID,jsonListOfObjectDefination,AllMessages,checkJobStatus){
            
            var Sboject={}
            Sboject.init=function(jsonObject){
                                
            }
            return Sboject
                                        
        })
        
        app.factory('AllMessages',function(){
            Object.size = function(obj) {
                var size = 0, key;
                for (key in obj) {
                    if (obj.hasOwnProperty(key)) size++;
                }
                return size;
            };
            
            return {
            	pagelevel:{},
            	blocklevel:{},
                fieldlevel:{},
				delete:function(level,blockIdentifier,messageIdentifier){
                	if(level=='fieldlevel'&&this[level][blockIdentifier]&&this[level][blockIdentifier][messageIdentifier]){
                		delete this[level][blockIdentifier][messageIdentifier]
            		}
                    if(level=='blocklevel'&&this[level][blockIdentifier]&&this[level][blockIdentifier][messageIdentifier]){
                        delete this[level][blockIdentifier][messageIdentifier]
                    }else if(level=='blocklevel'&&this[level][blockIdentifier])
						delete this[level][blockIdentifier]
                
					if(level=='pagelevel'&&this[level][blockIdentifier])
						delete this[level][blockIdentifier]
				},
				add:function(message,level,blockIdentifier,messageIdentifier){
					if(level=='fieldlevel'){
                        if(!this[level][blockIdentifier])
							this[level][blockIdentifier]={}
						this[level][blockIdentifier][messageIdentifier]=message
							
					}
                    if(level=='blocklevel'){
                        if(!this[level][blockIdentifier]){
                            this[level][blockIdentifier]={}
                        }    
                        if(!messageIdentifier){
                           messageIdentifier=new Date().getTime();     
                        }
                        this[level][blockIdentifier][messageIdentifier]=message
                    }
					if(this[level]&&level=='pagelevel'){
						this[level][blockIdentifier]=message
					}	
				}
            }
        })
        app.factory('checkJobStatus',function($salesforceApiForVf,$q){
            return function(id,interval){
                   var deferred=$q.defer()
                   if(!interval)
                       interval=3000
                   var jobstatus=$salesforceApiForVf.query($salesforceApiForVf.org,"SELECT Id, CreatedDate, JobType, ApexClassId, Status, JobItemsProcessed, TotalJobItems FROM AsyncApexJob where id='"+id+"'")
                   
                   var jobstatusfunction=function(data){
                            if(data.data.records&&data.data.records[0].Status=="Completed"){
                                deferred.resolve(data.data.records[0])
                            }
                       		if(data.data.records&&data.data.records[0].Status=="Failed" && data.data.records[0].JobItemsProcessed==data.data.records[0].TotalJobItems){
                                deferred.resolve(data.data.records[0])
                            }
                       	    if(data.data.records&& data.data.records[0].JobItemsProcessed<data.data.records[0].TotalJobItems){
                                deferred.notify(data.data.records[0])
                            }
                       		if(data.data.records&&data.data.records[0].Status!="Completed"){
                                $salesforceApiForVf.query($salesforceApiForVf.org,"SELECT Id, CreatedDate, JobType, ApexClassId, Status, JobItemsProcessed, TotalJobItems FROM AsyncApexJob where id='"+id+"'").then(function(data){
                                    jobstatusfunction(data)
                               },function(data){
                                    jobstatusfunction(data)
                               })
							}
                    }        
                   jobstatus.then(function(data){
                        jobstatusfunction(data)
                   },function(data){
                        jobstatusfunction(data)
                   })
                   return deferred.promise;
                        
            }
        })
        app.factory('extractRowMetadata',function(jsonListOfObjectDefination){
            return function(key,fieldpath){
                        if(fieldpath.indexOf('.')>-1){
                            fieldpath=fieldpath.substring(0,fieldpath.indexOf('.'))
                        }
                		try{
                        	return jsonListOfObjectDefination[key].fieldDescribeMap[fieldpath]
                        }catch(e){
                        	return null
                        }
                    }
        })
        app.controller('StandardAngularController', function($scope,jsonListOfObjectDefination,Sboject,AllMessages,$salesforceStreaming){
            $scope.AllMessages=AllMessages
            $salesforceStreaming.initialize()
            
            $scope.message='Loading'

            $scope.Sboject=Sboject
            $scope.Sboject.init(window.jsonObject)
            console.log($scope.Sboject)
            $scope.jsonListOfObjectDefination=jsonListOfObjectDefination
            console.log($scope.jsonListOfObjectDefination)
            console.log($scope.Sboject.RelatedListMap)
              
            $scope.pageChangeHandler = function(num) {
                console.log('meals page changed to ' + num);
            };           
        });
        app.factory('customexceptionMessages',function(){
            return function(message){
                if(message.indexOf('token')>0){
                    return "token related message "
                }
                return message;
            }
        })
        
        
        
        app.factory('dataOperation',function(remoteSave,remoteDelete,remoteInsert,reloadFactory,customexceptionMessages,AllMessages){
            return {
                		save:function(value,Id,scope,reloadlist){
                                    scope.operation="Saving..."
                                    //var originaltoJSON=Date.prototype.toJSON 
                                    //Date.prototype.toJSON = function(){ return this.getTime() }
                                    //value.updatedValues=angular.fromJson(angular.toJson(value.updatedValues))
                                    //Date.prototype.toJSON=originaltoJSON
                                    value.updatedValues=angular.fromJson(JSON.stringify( value.updatedValues, function( key, value ) {
                                        if( key === "$$hashKey" ) {
                                            return undefined;
                                        }
                                        if (this[key] instanceof Date) {
                                           return this[key].getTime();
                                        }
                                        return value;
                                    }))
                                    if(value.updatedValues&&!Id){
                                        if(!value.progress)
                                            value.progress={}
                                        value.progress['all']=true
                                        return remoteSave(value.updatedValues,"type").then(function(result){
                                            console.log(result);
                                            if(result=="success"){
                                                delete value.updatedValues
                                                delete value.progress['all']
												AllMessages.delete("pagelevel",value.Key,'New')
												reloadFactory(reloadlist)
                                            }else{
												AllMessages.add({
                                                 show:true,
                                                 removable:true,
                                                 styleClass:'error-message',
                                                 content:customexceptionMessages(result)
                                                },'pagelevel',value.Key,'New')
											
											}
                                            return result
                                            scope.operation=false
                                        })
                                        
                                                    
                                    }
                                    else if(value.updatedValues&&Id){
                                        var data={}
                                        data[Id]=value.updatedValues[Id]
                                        if(!value.progress)
                                            value.progress={}
                                        value.progress[Id]=true
                                        return remoteSave(data,"type").then(function(result){
                                            console.log(result);
                                            if(result=="success"){
                                                delete value.updatedValues[Id]
                                                AllMessages.delete("pagelevel",Id)//value.Key,Id)
                                                reloadFactory(reloadlist)
                                            }else{
                                                AllMessages.add({
                                                 show:true,
                                                 removable:true,
                                                 styleClass:'error-message',
                                                 content:customexceptionMessages(result)
                                                },'pagelevel',Id)//value.Key,Id)
                                                
                                            }
                                            delete value.progress[Id]
                                            
                                            scope.operation=false
                                            return result
                                        })
                                        
                                    }
                        },
                		saveAll:function(value,scope,reloadlist){
                                    scope.operation="Saving all..."
                                    value.updatedValues=angular.fromJson(JSON.stringify( value.updatedValues, function( key, value ) {
                                        if( key === "$$hashKey" ) {
                                            return undefined;
                                        }
                                        if (this[key] instanceof Date) {
                                           return this[key].getTime();
                                        }
                                        return value;
                                    }))
                                    /*if(value.updatedValues&&!Id){
                                        remoteSave(value.updatedValues,"type").then(function(result){
                                            console.log(result);
                                            if(result=="success"){
                                                delete value.updatedValues
                                                delete value.progress['all']
												AllMessages.delete("blocklevel",value.Key,'New')
												reloadFactory(reloadlist)
                                            }else{
												AllMessages.add({
                                                 show:true,
                                                 removable:true,
                                                 styleClass:'error-message',
                                                 content:customexceptionMessages(result)
                                                },'blocklevel',value.Key,'New')
											
											}
                                            
                                            scope.operation=false
                                        })
                                        if(!value.progress)
                                            value.progress={}
                                        value.progress['all']=true
                                                    
                                    }
                                    else*/ if(value.updatedValues){
                                        var data={}
                                        data=JSON.parse(JSON.stringify(value.updatedValues))
                                        remoteSave(data,"type").then(function(result){
                                            console.log(result);
                                            if(result=="success"){
                                                delete value.updatedValues
                                                AllMessages.delete("blocklevel",value.Key,Id)
                                                reloadFactory(reloadlist)
                                            }else{
                                                AllMessages.add({
                                                 show:true,
                                                 removable:true,
                                                 styleClass:'error-message',
                                                 content:customexceptionMessages(result)
                                                },'blocklevel',value.Key,Id)
                                                
                                            }
                                            delete value.progress[Id]
                                            
                                            scope.operation=false
                                        })
                                        if(!value.progress)
                                            value.progress={}
                                        for (Id in value.updatedValues) {
                                            if ( value.updatedValues.hasOwnProperty(Id) )
                                                value.progress[Id]=true
                                        }
                                        
                                    }
                        },
                		delete:function(value,Id,scope,reloadlist){
                                    scope.operation="Deleting..."
                                    if(!value.progress)
                                            value.progress={}
                                    value.progress[Id]=true
                    
                                    remoteDelete([{Id:Id}]).then(function(result){
                                            console.log(result);
                                            if(result=="success"){
                                                scope.operation=""
                                                reloadFactory(reloadlist)
                                                delete value.progress[Id]
                                                AllMessages.delete("pagelevel",Id)//value.Key,Id)
                                            }else{
                                               AllMessages.add({
                                                 show:true,
                                                 removable:true,
                                                 styleClass:'error-message',
                                                 content:customexceptionMessages(result)
                                                },"pagelevel",Id)//value.Key,Id)
                                                scope.operation=""
                                                delete value.progress[Id]
                                            }
                                    })
                                },
                        insert:function(value,$scope,reloadlist){
                            		var tosave=[]
                                    value.data.forEach(function(v1,k){
                                        var v=v1.postData(v1,value.updatedValues,k)
                                        
                                        tosave.push(v)
                                    })
                                    tosave=angular.fromJson(JSON.stringify( tosave, function( key, value ) {
                                        if( key === "$$hashKey" ) {
                                            return undefined;
                                        }
                                        if (this[key] instanceof Date) {
                                            return this[key].getTime();
                                        }
                                        return value;
                                    }))
                                    $scope.servering=true
                                    return remoteInsert(tosave).then(function(result){
                                        
                                        
                                        if(result.data.length==0){
                                            
                                            //delete relatedlist.creatingNew
                                            AllMessages.add({
                                                show:true,
                                                removable:true,
                                                styleClass:'error-message',
                                                content:customexceptionMessages(result.message)
                                            },'blocklevel',value.Key+'New')
                                        }else{
                                            AllMessages.delete("blocklevel",value.Key+'New')
                                            reloadFactory(reloadlist)
                                            return result    
                                        }
                                        $scope.servering=false
                                        return result
                                    },function(error){
                                        console.log(error);
                                        $scope.servering=false
                                        alert("something went wrong  try again")
                                        return error
                                    })
                        }
                   }
        })    
        app.factory("reloadFactory",function(){
        	return function(reloadlist){
            	if(reloadlist&&reloadlist  instanceof  Array){
                    reloadlist.forEach(function(objecttoreload){
                        objecttoreload.reload()
                    })
                }
                if(reloadlist&&reloadlist  instanceof  Object &&!(reloadlist  instanceof  Array)){
                    reloadlist.reload()
                }
            }
        })
        app.factory("templateFactory",function($http,$templateCache,$compile,$parse,$sce,RESOURCEPATH){
            var allTplPromise
        	var templatefactory= function(element,scope,templatename,defaulttemplatename,constructor){
                if (!allTplPromise) {
                    
                    $http.get(RESOURCEPATH+'/alltemplates.html').then(function(response) {
                      // compile the response, which will put stuff into the cache
                      //console.log(response.data);
                      var el = document.createElement( 'html' );
					  el.innerHTML =response.data
                      el.querySelectorAll('template[type="text/ng-template"]').forEach(function(v){
                           $templateCache.put(v.getAttribute('Id'),v.innerHTML)
                      })
                      el.querySelectorAll('script[type="text/ng-template"]').forEach(function(v){
                           if(!$templateCache.get(v.getAttribute('Id')))
                           	$templateCache.put(v.getAttribute('Id'),v.innerHTML)
                      })
                      templatefactory(element,scope,templatename,defaulttemplatename,constructor)
                      allTplPromise = true
                    });
                    return
                }
                if(constructor.element&&constructor.element!=undefined){
                    var newDiv = document.createElement("elemnet"); 
                    newDiv.append(constructor.element);
                    
                    element.replaceWith($compile("<div>"+newDiv.innerText+"</div>")(scope));
                    return "<div>"+newDiv.innerText+"</div>"
                }
                var template=RESOURCEPATH+"/"+(constructor.prepend||'')+templatename.toLowerCase()+(constructor.append||'')
                var scripttemplate=(constructor.prepend||'')+templatename.toLowerCase()+(constructor.append||'')
                var defaulttemplate=RESOURCEPATH+"/"+(constructor.prepend||'')+defaulttemplatename.toLowerCase()+(constructor.append||'')
                var defaultscripttemplate=(constructor.prepend||'')+defaulttemplatename.toLowerCase()+(constructor.append||'')
                    
                if($templateCache.get(scripttemplate)){
                    element.replaceWith($compile($templateCache.get(scripttemplate))(scope));
                    return $templateCache.get(scripttemplate)
                }else if($templateCache.get(defaultscripttemplate)){
                    element.replaceWith($compile($templateCache.get(defaultscripttemplate))(scope));
                    return $templateCache.get(defaultscripttemplate)
                }else if($templateCache.get(template)){
                    element.replaceWith($compile($templateCache.get(template)[1])(scope));
                    return $templateCache.get(template)[1]
        		}else if(!allTplPromise)   
                    return $http.get(template, { cache: $templateCache })
                        .then(
                            function (res) {
                                //console.log('templateContent: ', JSON.stringify(res.data));
                                element.replaceWith($compile(res.data)(scope));
                                return res.data
                            },
                            function(errorres){
                                console.log(errorres)
                                $http.get(defaulttemplate, { cache: $templateCache }).then(function (res) {
                                    console.log('templateContent: ', JSON.stringify(res.data));
                                    element.replaceWith($compile(res.data)(scope));
                                    $templateCache.put(template,$templateCache.get(defaulttemplate)[1])
                                    element.replaceWith($compile($templateCache.get(template))(scope));
                                    return $templateCache.get(template)
                                })
                        	}
                        );
           };
            return templatefactory
        })
        app.service('controllerFactory', ['$controller', function($controller) {
            return {
                exists: function(controllerName) {
                    if(typeof window[controllerName] == 'function') {
                        return true;
                    }
                    try {
                        
                        $controller(controllerName);
                        return true;
                    } catch (error) {
                        return !(error instanceof TypeError);
                    }
                }.bind(this),
                set:function(scope,elem,attrs){
                    attrs.$observe('ctrl', function(name) {
                        if (name) {
                          elem.data('$Controller', $controller(name, {
                            $scope: scope,
                            $element: elem,
                            $attrs: attrs
                          }));
                        }
                      });
               		}.bind(this)
                
            };
        }])
        
		app.factory('remoteSave', ['$q', '$rootScope', function($q, $rootScope,VisualforceRemotingManager) {
            return function(data,type) {
                var deferred = $q.defer();
                Visualforce.remoting.Manager.invokeAction(
                    'StandardAngularController.save',
                    data,
                    function(result, event) {
                        $rootScope.$apply(function() {
                            if (event.status) {
                                deferred.resolve(result);
                            } else {
                                deferred.reject(event);
                            }
                        })
                    },
                    { buffer: true, escape: true, timeout:  120000 }
                );
                return deferred.promise;
            }
        }])
        app.factory('remoteInsert', ['$q', '$rootScope', function($q, $rootScope) {
            return function(data) {
                var deferred = $q.defer();
                Visualforce.remoting.Manager.invokeAction(
                    'StandardAngularController.insertData',
                    data,
                    function(result, event) {
                        $rootScope.$apply(function() {
                            if (event.status) {
                                deferred.resolve(JSON.parse(result));
                            } else {
                                deferred.reject(event);
                            }
                        })
                    },
                    { buffer: true, escape: false, timeout:  120000 }
                );
                return deferred.promise;
            }
        }])
        app.factory('remoteDelete', ['$q', '$rootScope', function($q, $rootScope) {
            return function(data) {
                var deferred = $q.defer();
                Visualforce.remoting.Manager.invokeAction(
                    'StandardAngularController.deleteData',
                    data,
                    function(result, event) {
                        $rootScope.$apply(function() {
                            if (event.status) {
                                deferred.resolve(result);
                            } else {
                                deferred.reject(event);
                            }
                        })
                    },
                    { buffer: true, escape: true, timeout:  120000 }
                );
                return deferred.promise;
            }
        }])
        app.filter('Extractdata',function(){
            return function getPropByString(obj, propString) {
                if (!propString)
                    return obj;
            
                var prop, props = propString.split('.');
            
                for (var i = 0, iLen = props.length - 1; i < iLen; i++) {
                    prop = props[i];
            
                    var candidate = obj[prop];
                    if (candidate !== undefined) {
                        obj = candidate;
                    } else {
                        break;
                    }
                }
                return obj[props[i]];
            }

        
        })
        app.filter('toArray', function () {
          return function (obj, addKey) {
            if (!angular.isObject(obj)) return obj;
            if ( addKey === false ) {
              return Object.keys(obj).map(function(key) {
                return obj[key];
              });
            } else {
              return Object.keys(obj).map(function (key) {
                var value = obj[key];
                return angular.isObject(value) ?
                  Object.defineProperty(value, '$key', { enumerable: false, value: key}) :
                  { $key: key, $value: value };
              });
            }
          };
        })
        app.filter('groupBy', function($parse) {
            return _.memoize(function(items, field) {
                var getter = $parse(field);
                return _.groupBy(items, function(item) {
                    return getter(item);
                });
            });
        });
        app.directive('ngClickNodigest', function ($parse) {
            return {
                compile : function ($element, attr) {
                    var fn = $parse(attr['ngClickNodigest']);
                    return function (scope, element, attr) {
                        element.on('click', function (event) {
                            fn(scope, {
                                $event : event,
                                $element : element
                            });
                        });
                    };
                }
            };
        })
        app.directive("message", function($compile){
            return {
                scope: {
                    messageShow: '=',
                    messageStyleClass:'=',
                    messageContent: '=',
                    messageObject: '=',
                    messagesObject: '=',
                    messageObjectKey:'='
                },
                template: '<div ng-show="messageShow" class="{{messageStyleClass}}" style="position: relative;">'
                          +'<loader ng-show="messageObject.showloader" ></loader>'
                          +'<div>{{messageContent}}</div>'
                          +'<div ng-show="messageObject.removable" class="glyphicon glyphicon-remove" ng-click="deleteMessage()" style="position: absolute;top: 0;left: 0;background: white;color: black;padding: 5px;border-radius: 50%;margin: -5px;border: 1px solid blue;"></div>'
                          +'</div>',
                link: function(scope, element, attrs){
                    scope.deleteMessage=function(){ 
                       delete scope.messagesObject[scope.messageObjectKey]
                    }
                }
            };
        });
        app.directive('dynamicModel', ['$compile', '$parse', function ($compile, $parse) {
            return {
                restrict: 'A',
                terminal: true,
                priority: 100000,
                link: function (scope, elem) {
                    var name = $parse(elem.attr('dynamic-model'))(scope);
                    elem.removeAttr('dynamic-model');
                    elem.attr('ng-model', name);
                    $compile(elem)(scope);
                }
            };
        }]);
        app.directive('dynamicName', ['$compile', '$parse', function ($compile, $parse) {
            return {
                restrict: 'A',
                terminal: true,
                priority: 100000,
                link: function (scope, elem) {
                    var name = $parse(elem.attr('dynamic-name'))(scope);
                    elem.removeAttr('dynamic-name');
                    elem.attr('name', name);
                    $compile(elem)(scope);
                }
            };
        }]);
        app.directive("column", function($compile){
            return {
                require: "?ngModel",
                scope: {
                    value: '=ngModel',
                    editable:'=isEditable',
                    readOnly: '='
                },
                transclude: true,
                compile: function(element, attrs) {
                    //element.append('<div ng-include="\'' + attrs.type + '-template.html\'"></div>')
                },
                //template: "<span ng-show='readOnly'>{{value}}</span><input ng-hide='readOnly' ng-model='value' ng-change='onChange()'>",
                link: function(scope, element, attrs, ngModel){
                    if (!ngModel) return;
                    
                    scope.onChange = function(){
                        ngModel.$setViewValue(scope.value);
                    };
                    
                    ngModel.$render = function(){
                        scope.value = ngModel.$modelValue;
                    };
                }
            };
        });
        
        app.directive("block", function($compile,$templateCache,$http,templateFactory,controllerFactory){
            return {
                scope: {
                    value: '=',
                    visible:'=',
                    data: '=value',
                    parentdata:'=',
                    blockType:'=',
                    ctrl:"=?",
                    block:"=?"
                    
                },
                transclude: true,
                replace:true,
                restrict:"E",
                controller:['$controller', '$scope','controllerFactory', function($controller, $scope,controllerFactory) {
                  if(controllerFactory.exists($scope.blockType+'_BlockController')){
                  	  $scope.ctrl=$scope.blockType+'_BlockController'
                  }else{
                      $scope.ctrl='Default_BlockController'
                  }
                  var ctrl= $controller($scope.ctrl, {$scope: $scope});
                  return ctrl;
                }],
                link:{
                    pre: function( scope, element, attrs ) {
                    },
                	post :function(scope, element, attrs,ctrl){
                          
                          console.log("Block Used :"+(scope.blockType||'default')+' controller used'+scope.ctrl)
                          templateFactory(
                              element,
                              scope,
                              (scope.blockType||'default').toLowerCase(),
                          	  'default',
                              {
                              	append:".block.html"
                              }
                          )
                          if(!scope.block)
                          scope.block={
                          }
                }
            }
            };    
        });
        app.controller("Default_BlockController",function($scope,$parse,$uibModal,$document,$rootScope,extractRowMetadata,Sboject,AllMessages,customexceptionMessages){
                  
        })
        app.controller("RelatedList_BlockController",function($scope,$filter,$parse,$uibModal,$document,$rootScope,extractRowMetadata,Sboject,AllMessages,customexceptionMessages){
                  $scope.extractRowMetadata=extractRowMetadata
                  if($scope.value){
                  	$scope.value.pageSize=10;$scope.value.currentPage=1
                  }else{
                    console.log('value not defined')
                  }  
                  $scope.$watch(function(){
                     if($scope.value&&$scope.value.data )
                     	return $scope.value.data 
                  },function(newval,oldval){
                     if($scope.value&&$scope.value.data )
                     	$scope.filterdata()         
                  })
                  $scope.filterdata = function (filtervalue) {
                    var filtered = $filter('filter')($scope.value.data, filtervalue);
                    //filtered = $filter('orderBy')(filtered, 'name');
                    $scope.value.filtereddata = filtered;
                  };
        })
        app.controller("Object_BlockController",function($scope,$parse,$uibModal,$document,$rootScope,extractRowMetadata,Sboject,AllMessages,customexceptionMessages){
                  $scope.extractRowMetadata=extractRowMetadata
        })
		app.controller("Message_BlockController",function($scope,$parse,$uibModal,$document,$rootScope,extractRowMetadata,Sboject,AllMessages,customexceptionMessages){
                  
        })
         
        app.directive("actionbutton", function(templateFactory ,controllerFactory){
            return {
                scope: {
                    label: '=label',
                    name:'=',
                    buttonType:'=',
                    disable:'=',
                    visible:'=',
                    data: '=',
                    parentdata:'=',
                    ctrl:"=?"
                    
                },
                transclude: true,
                replace:true,
                controller:['$controller', '$scope','controllerFactory', function($controller, $scope,controllerFactory) {
                  if(controllerFactory.exists($scope.name+'_ButtonController')){
                  	  $scope.ctrl=$scope.name+'_ButtonController'
                  }else{
                      $scope.ctrl='Default_ButtonController'
                  }
                  var ctrl= $controller($scope.ctrl, {$scope: $scope});
                  return ctrl;
                }],
                //template: "<span ng-show='readOnly'>{{value}}</span><input ng-hide='readOnly' ng-model='value' ng-change='onChange()'>",
                link:{
                    pre: function( scope, element, attrs ) {
                    },
                	post :function(scope, element, attrs,ctrl){
                          
                          templateFactory(
                              element,
                              scope,
                              (scope.buttonType||"button").toLowerCase(),
                          	  'button',
                              {
                                  append:scope.disable?".disabled.html":".html"
                              }
                          )
                          scope.button={
                              label:scope.label,
                              action:scope.action,
                              disable:scope.disable,
                              visible:scope.visible
                          }
                }
            }
            };    
        });
        app.controller("Default_ButtonController",function($scope){
                  $scope.action=function(){
                  	console.log('button clicked')
                    
                  }
        })
        app.controller("New_ButtonController",function($scope,$uibModal,$document,SbojectConstruction,RESOURCEPATH,dataOperation,extractRowMetadata ,AllMessages,customexceptionMessages){
            	  
                  var $uibModalInstance
                  $scope.AllMessages=AllMessages
                  $scope.action=function(){
                        console.time('createNew')
                        console.log('new button clicked')
                        $scope.uibModalInstance=$uibModal.open({
                            animation: true,
                            templateUrl: RESOURCEPATH+"/"+'newSobjectModal.html',
                            size:'lg',
                            scope:$scope,
                            backdrop :'static',
                            appendTo:angular.element($document[0].getElementById("controller"))
                        })
                        $scope.uibModalInstance.result.then(function (data) {
                            
                        }, function () {
                                    
                        });
                      	
                    
                  }
                  var relatedProperties=[]
                  
                  
                  $scope.newRelatedList= SbojectConstruction.getSbojectWrapperNew($scope.data.NewViewDefination)
                  console.log($scope.newSobject)
                  
                  $scope.newRelatedList.data=[];
            	  $scope.newRelatedList.prototype=SbojectConstruction.getPrototypeNew($scope.newRelatedList.displayFields,$scope.newRelatedList.Key,{})
                  console.log($scope.newRelatedList.prototype)
                  var fieldname=$scope.newRelatedList.prototype.getRelationShipName($scope.parentdata.Key,$scope.newRelatedList.Key)
                  console.log(fieldname)
                  if(fieldname){
                    $scope.$watch(function(){
                        if($scope.parentdata&&$scope.parentdata.data&&$scope.parentdata.data[0]&&$scope.parentdata.data[0].Id)
                        	return $scope.parentdata.data[0]
                    },function(newVal,oldVal){
                        if(newVal){
                            $scope.newRelatedList.prototype[fieldname]={Id:$scope.parentdata.data[0].Id,Name: $scope.parentdata.data[0].Name}
                            $scope.newRelatedList.data.forEach(
                                function(v){
                                    v[fieldname]={Id:$scope.parentdata.data[0].Id,Name: $scope.parentdata.data[0].Name}
                                }
                            )
                        }    
                    })
                  	
                  }
                  
                  $scope.addMoreNew=function(){
                     row=angular.copy($scope.newRelatedList.prototype)
                     if(!$scope.newRelatedList.data)
                         $scope.newRelatedList.data=[]
                         
                  	 row.Id=$scope.newRelatedList.data.length
                     $scope.newRelatedList.data.push(row)
                  }
                  $scope.addMoreNew()
                  $scope.removeNew=function(index){
                      $scope.newRelatedList.data.slice(index,1)
                  }
            
                  $scope.save = function () {
                      dataOperation.insert($scope.newRelatedList,$scope,[$scope.parentdata,$scope.data])
                      .then(function(result){
                          delete $scope.newRelatedList.data
                          delete $scope.newRelatedList.updatedValues
                          $scope.addMoreNew()
                          $scope.uibModalInstance.close(result);
                      })
                      //
                  };
            	  $scope.cancel = function () {
                            $scope.uibModalInstance.dismiss('cancel');
                  };

                  
        })
        app.controller("Save_ButtonController",function($scope,dataOperation,AllMessages,customexceptionMessages){
                  $scope.action=function(){
                  	console.log('save button clicked',$scope)
                    dataOperation.save($scope.data,$scope.data.data[0].Id,$scope,[$scope.parentdata])
                  }
        })
        
        app.directive("fieldLabel", function(templateFactory,controllerFactory,controllerFactory){
            return {
                scope: {
                    labelname: '<',
                    fieldtype:'<',
                    currentobject:'<',
					parentdata:'=?',
                    ctrl:"<?"
                },
                transclude: true,
                replace:true,
                controller:['$controller', '$scope','controllerFactory', function($controller, $scope,controllerFactory) {
                  if(controllerFactory.exists($scope.blockType+'_fieldLabelController')){
                  	  $scope.ctrl=$scope.blockType+'_fieldLabelController'
                  }else{
                      $scope.ctrl='Default_fieldLabelController'
                  }
                  var ctrl= $controller($scope.ctrl, {$scope: $scope});
                  return ctrl;
                }],
                link:{
                    pre: function( scope, element, attrs ) {
                    },
                	post :function(scope, element, attrs,ctrl){
                          
                          templateFactory(
                              element,
                              scope,
                              (scope.fieldLabelType||"default").toLowerCase(),
                          	  'default',
                              {
                              	append:".fieldLabel.html",
                                element:scope.labelname
                              }
                          )
                        
                          scope.fieldLabel={
                              
                          }
                }
            }
            };    
        });
        app.controller("Default_fieldLabelController",function($scope){
                  
        })
        
        app.directive("field", function($controller,templateFactory,controllerFactory,$compile,$parse,$uibModal,$document,extractRowMetadata){
            return{
                scope:{
                  parentref:"=",
                  a:"=ngData",
                  readOnly:"<",
                  fieldType:"<",
                  template:"<",
                  isColumn:"<",
                  rowData:"<",
                  rowMetadata:"<",
                  metadataKey:"<",
                  metadataApiName:"<",  
                  rowParent:"<",
                  currentobject:"<",
                  styleClass:"=",
                  ctrl:"=?",
                  definition:"="
                },
                transclude: true,
                replace:true,
                controller:['$controller', '$scope','controllerFactory', function($controller, $scope,controllerFactory) {
                  if(!$scope.ctrl)
                      $scope.ctrl='FieldDefaultController'
                  else if(!controllerFactory.exists($scope.ctrl)){
                  	  $scope.ctrl='FieldDefaultController'
                  }
                  var ctrl= $controller($scope.ctrl, {$scope: $scope});
                  return ctrl;
                }],
                //name: 'ctrl',
                //controller: '@',
                //controllerAS: 'feild',
                link:{
                    pre: function( scope, element, attrs ) {
                          attrs.ngData=scope.a
                    },
                	post :function(scope, element, attrs,ctrl){
                          
                          templateFactory(
                              element,
                              scope,
                              (scope.definition.template||"string").toLowerCase(),
                          	  'string',
                              {
                                  append:scope.readOnly?".readonly.html":".html"
                              }
                          )
                          if(scope.a)
                          scope.field={
                              key:scope.a,
                              value:scope.b,
                              actual:scope.b,
                              updated:false
                          }
                          //console.log('initilizing field '+scope.field.key)
                          if(scope.currentobject){
                               if(!scope.currentobject.updatedValues) {
                                    scope.currentobject.updatedValues={}
                               }  
                          }
                          
                   		  scope.rowMetadata=extractRowMetadata(scope.metadataKey,scope.metadataApiName)
                          if(scope.rowParent&&scope.rowParent.validations&&scope.rowParent.validations[scope.metadataApiName]){
                              scope.rowParent.validations[scope.metadataApiName].element=element
                          }
                          function update(){
                              if(typeof scope.trigger==="function"){
                              	scope.trigger();
                                //console.log('deregistring change watcher for '+scope.field.key)
                              }
                              
                              scope.field.updated=false
                              if(scope.fieldType=="LOOKUP"&&scope.rowMetadata){
                                scope.field.value = $parse(scope.rowMetadata.relationshipName)(scope.rowData)
                                scope.field.particularfield=scope.metadataApiName.split('.')[1]
                              }
                              else if(scope.fieldType=="DATE"&&scope.rowMetadata){
                                if($parse(scope.rowMetadata.name)(scope.rowData))
                                	scope.field.value = new Date($parse(scope.rowMetadata.name)(scope.rowData))
                                                                   
                                scope.field.actual=scope.field.value;
                                if(scope.currentobject&&scope.currentobject.updatedValues&&scope.rowData&&
                                   scope.currentobject.updatedValues[scope.rowData.Id]&&
                                   scope.currentobject.updatedValues[scope.rowData.Id][scope.field.key.replace(scope.parentref,'')]){ 
                                          scope.field.value=scope.currentobject.updatedValues[scope.rowData.Id][scope.field.key.replace(scope.parentref,'')]
                                   		  scope.field.updated=true
                                }
                              }
                              else if(scope.rowMetadata){
                                scope.field.value = $parse(scope.rowMetadata.name)(scope.rowData)
                                scope.field.actual=scope.field.value;
                                if(scope.currentobject&&scope.currentobject.updatedValues&&scope.rowData&&
                                   scope.currentobject.updatedValues[scope.rowData.Id]&&
                                   scope.currentobject.updatedValues[scope.rowData.Id][scope.field.key.replace(scope.parentref,'')]){ 
                                          scope.field.value=scope.currentobject.updatedValues[scope.rowData.Id][scope.field.key.replace(scope.parentref,'')]
                                   		  scope.field.updated=true
                                }
                              }
                              //console.log('registring change watcher for '+scope.field.key)
                              scope.trigger=scope.$watch(
                                  function(){
                                      return scope.field;
                                  },
                                  function(newvalue,oldvalue){
                                      if(newvalue === oldvalue)
                                          return
                                      console.log(JSON.stringify(newvalue),JSON.stringify(oldvalue))
                                      console.log('field change watch for '+scope.field.key)
                                      if(scope.rowMetadata)
                                      scope.update(newvalue.value)
                                  }, true
                              )
                          }
                  		  //update()
                          
						  scope.$watch(
                              function(){
                                  return scope.rowData;
                              },
                              function(newvalue,oldvalue){
                                    //console.log(newvalue,oldvalue)
                                    console.log('rowdata change watch'+scope.field.key)
									update()
                                    //
                              }, true
                          )
                          
                  		  	
                  		  scope.update= function(b) {
                      		  if(!scope.rowMetadata)
                                  scope.rowMetadata=extractRowMetadata(scope.metadataKey,scope.metadataApiName)
                              
                      
                              if(scope.currentobject){
                                  var data={}  
                                  if(scope.rowData&&!scope.currentobject.updatedValues[scope.rowData.Id]){
                                      var data={}
                                      data['Id']=scope.rowData.Id
                                      
                                      if(scope.fieldType=="LOOKUP"){
                                          data[scope.rowMetadata.name]=scope.field.value?scope.field.value.Id:null
                                      }
                                      if(scope.fieldType=="operationselect"){
                                          
                                      }
                                      if(!(scope.fieldType=="operationselect"||scope.fieldType=="LOOKUP")){
                                          data[scope.rowMetadata.name]=scope.field.value
                                      }
                                      scope.currentobject.updatedValues[scope.rowData.Id]=data
									  scope.field.updated=true                                      
                                  }else if(scope.rowData&&scope.currentobject.updatedValues[scope.rowData.Id]){
                                      if(scope.fieldType=="LOOKUP"){
                                          scope.currentobject.updatedValues[scope.rowData.Id][scope.rowMetadata.name]=scope.field.value?scope.field.value.Id:null
                                      }
                                      if(scope.fieldType=="operationselect"){
                                          
                                      }
                                      if(!(scope.fieldType=="operationselect"||scope.fieldType=="LOOKUP")){ 
                                          scope.currentobject.updatedValues[scope.rowData.Id][scope.rowMetadata.name]=scope.field.value
                                      }
                                      scope.field.updated=true
                                  }
                              }
                          if(scope.rowData&&scope.currentobject&&(scope.field.actual==scope.field.value
                                                   ||(scope.field.actual  instanceof Date && scope.field.actual.getTime()===scope.field.value.getTime()))){
                              delete scope.field.updated
                              
                              if(Object.keys(scope.currentobject.updatedValues[scope.rowData.Id]).length<=2)
                                  delete scope.currentobject.updatedValues[scope.rowData.Id]
                              else
                                  delete scope.currentobject.updatedValues[scope.rowData.Id][scope.rowMetadata.name]//delete scope.currentobject.updatedValues[scope.rowData.Id][scope.a.replace(scope.parentref,'')]
                          }
                  };
                   
                }
        		}
            }
        })
        app.controller("FieldDefaultController",function($scope){
                   var scope=$scope
                   
        })
        app.controller("DATE",function($scope){
                   var scope=$scope
                   scope.toggleDatepopup=function(){
                    scope.datepopup=true
                   }
        })
        app.controller("PERCENT",function($scope){
                   var scope=$scope
                  
        })
        app.controller("PICKLIST",function($scope,$rootScope,$filter,extractRowMetadata,Sboject,AllMessages,customexceptionMessages){
                   var scope=$scope
                   scope.selectionChanged=function(b){
                        scope.field.value=b
                        //scope.update();
                   }
                   var initializedependency=function(){
                       var picklistValues=$scope.rowMetadata.allpicklistValues=angular.copy($scope.rowMetadata.picklistValues)
                       var controllerpicklistValues=extractRowMetadata($scope.metadataKey,$scope.rowMetadata.controllerName).picklistValues
                       
                       
                       $scope.$watch(function(){
                         if($scope.rowData&&$scope.currentobject.updatedValues&&$scope.currentobject.updatedValues[$scope.rowData.Id]){
                            return $scope.currentobject.updatedValues[$scope.rowData.Id][$scope.rowMetadata.controllerName]
                         }
                         else if($scope.rowData){
                            return $scope.rowData[$scope.rowMetadata.controllerName] 
                             
                         }
                       },function(newval,oldval){
                           console.log(newval)
                           if(newval&&$scope.rowData)
                            $scope.filtervalues(newval)         
                       })
                   
                       function isDependentValue(index, validFor)
                       {
                            var base64 = new sforce.Base64Binary("");
                            var decoded = base64.decode(validFor);
                            var bits = decoded.charCodeAt(index>>3);
                            
                            return ((bits & (0x80 >> (index%8))) != 0);
                       }
            	        
                       
                          
                       $scope.filtervalues = function (filtervalue) {
                           console.log(filtervalue)
                           var filteredvalues=[]
                           for(var item = 0; item < controllerpicklistValues.length; item++)
                            {
                                if(controllerpicklistValues[item].value.toLowerCase() == filtervalue.toLowerCase())
                                 {
                                    for(var i = 0; i < picklistValues.length; i++)
                                    {
                                        if(isDependentValue(item, picklistValues[i].validFor))
                                        {
                                            var newValue = new Object();
                                            newValue.label = picklistValues[i].label;
                                            newValue.value = picklistValues[i].value;
                                            newValue.default = picklistValues[i].defaultValue;
                                            newValue.validFor = picklistValues[i].validFor;
                                            newValue.validForName =controllerpicklistValues[item].value;
                                            filteredvalues.push(newValue);                                                               
                                        }
                                    }
                                }
                            }	
                           
                           console.log(filteredvalues)
                           $scope.rowMetadata.picklistValues=filteredvalues
                       }
                   } 
            	   $scope.$watch(function(){
            	   		if($scope.rowMetadata&&$scope.rowMetadata.controllerName&&$scope.rowMetadata.controllerName!=null)
                       		return true;
                       },function(newval){
                           if(newval)
                           initializedependency()
                       }   
                   )
        })
        app.controller("DATE",function($scope,$parse,$uibModal,$document,$rootScope,Sboject,AllMessages,customexceptionMessages){
                   var scope=$scope
                   scope.toggleDatepopup=function(){
                    	scope.datepopup=true
                   }
                  
                  
        })
        app.controller("LOOKUP",function($scope,$parse,$uibModal,$document,$salesforceApiForVf,RESOURCEPATH,Sboject,SbojectConstruction,extractRowMetadata,AllMessages,customexceptionMessages){
                   var scope=$scope
                   var $uibModalInstance;
                   scope.$watch(function(){return scope.rowMetadata},function(){
                       if(!scope.rowParent.lookupViewDefination||(scope.rowParent.lookupViewDefination&&scope.rowMetadata&&!scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']])){
                           $salesforceApiForVf.getSearchLayout($salesforceApiForVf.org,scope.rowMetadata['referenceTo'].join(',')).then(
                                function(response){
                                    if(!scope.rowParent.lookupViewDefination)
                                        scope.rowParent.lookupViewDefination={}
                                    var SObjectSearchMap={};
                                    SObjectSearchMap.Key=scope.rowMetadata['referenceTo'][0];
                                    SObjectSearchMap.name=scope.rowMetadata['referenceTo'][0].split('_').join(' ');
                                    SObjectSearchMap.Fields=[];
                                    SObjectSearchMap.Filter=[];
                                    SObjectSearchMap.data=[];
                                    SObjectSearchMap.displayColums=[];
                                    if(!response.data[0].errorMsg){
                                        response.data[0].searchColumns.forEach(function(value){
                                            SObjectSearchMap.Fields.push(value.name)
                                            if(value.name.indexOf("toLabel(")==0)
                                                value.name=value.name.split("toLabel(")[1].split(')')[0]
                                                SObjectSearchMap.displayColums.push(SbojectConstruction.getDisplayfieldNew({
                                                    LabelName:value.label,
                                                    apiName:value.name,
                                                    editable:false, 
                                                    typeoffield:'STRING',
                                                    controller:'STRING',
                                                    template:'STRING'
                                                }))
                                        })
                                        /*var  wherepart='';
                                        if(SObjectSearchMap.Filter.length>0){
                                            wherepart=' where '+SObjectSearchMap.Filter.join(',');
                                        }
                                        SObjectSearchMap.recentQuery='SELECT '+SObjectSearchMap.Fields.join(',')+' RecentlyViewed WHERE Type IN (\''+SObjectSearchMap.key+'\') ORDER BY LastViewedDate DESC ';
                                        SObjectSearchMap.query='FIELDS RETURNING '+SObjectSearchMap.Key+' (Id,'+SObjectSearchMap.Fields.join(',')+')';
										*/                                        
                                        scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']]=SbojectConstruction.getSbojectWrapperNew(SObjectSearchMap)
                                        scope.relatedSobject=scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']]
                                        scope.relatedSobject.data=[]
                                        if(scope.relatedSobject.displayColums)
                                        scope.filterName=scope.relatedSobject.displayColums[0].apiName
                                	}
                                }
                           )
                       }
                       else if(scope.rowParent.lookupViewDefination&&scope.rowMetadata&&scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']]){
                           scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']]=SbojectConstruction.getSbojectWrapperNew(scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']])
                           scope.relatedSobject=scope.rowParent.lookupViewDefination[scope.rowMetadata['relationshipName']]
                           scope.relatedSobject.data=[]
                           if(scope.relatedSobject.displayColums&&scope.relatedSobject.displayColums[0])
                           scope.filterName=scope.relatedSobject.displayColums[0].apiName
                       }
                       
                   })
                   scope.lookupRemove=function(){
                            scope.field.value=null;
                           //scope.update();
                   }
                   if(!scope.rowMetadata)
                   	scope.rowMetadata=extractRowMetadata(scope.metadataKey,scope.metadataApiName)
                   
                   scope.lookup=function(searchValue,size) {
                            console.log(scope.rowMetadata);console.log(scope.rowData);console.log(scope.rowParent);
                            $uibModalInstance= $uibModal.open({
                              animation: true,
                              templateUrl: RESOURCEPATH+"/"+'lookupModal.html',
                              size: size,
                              scope:scope,
                              appendTo:angular.element($document[0].getElementById("controller"))
                            });
                        
                            $uibModalInstance.result.then(function (selectedItem) {
                                    scope.field.value=selectedItem
                                    
                                    //scope.update(scope.b)
                                
                            }, function () {
                             
                            });
                    
                   }
                   scope.$watch(function(){
                       return scope.field.value
                   },function(newVal){
                       if(scope.rowData){
                           if(!scope.rowParent.LookupCache){
                               scope.rowParent.LookupCache={}
                           }
                           if(!scope.rowParent.LookupCache[scope.rowData.Id]){
                               scope.rowParent.LookupCache[scope.rowData.Id]={}
                           }
                           scope.rowParent.LookupCache[scope.rowData.Id][scope.rowMetadata.relationshipName]=scope.field.value
                        }
                   })
                   
                   scope.search=function(filterValue){
                        scope.message="Loading.."
                        
                        scope.servering=true
                        
                        return $salesforceApiForVf.search($salesforceApiForVf.org,scope.relatedSobject.processQuery(filterValue).searchQuery).then(
                              function(data){
                                  scope.relatedSobject.data=data.data.searchRecords
                                  scope.servering=false
                              },function(error){
                                    scope.message="No results found"
                                    scope.servering=false
                              }
                        ).then(function(response){
                              return scope.relatedSobject.data.map(function(item){
                                return item;
                              });
                        });
                   }
                   
                   if(scope.filterValue=='' || scope.filterValue==undefined ||( scope.filterValue && scope.filterValue.length < 3) ){
                       $scope.message="Please enter search term having more than three characters"
                   }
                   scope.select=function(item,event){
                       $uibModalInstance.close({Id:item.Id,Name:item.Name});
                   }
              
                   scope.ok = function () {
                        $uibModalInstance.close($ctrl.selected.item);
                   };
            
              	   scope.cancel = function () {
                    	$uibModalInstance.dismiss('cancel');
              	   };
                                      
        })
        //Field Controllers
        app.controller("lookup.particularfield",function($scope){
            var scope=$scope
            scope.$watch(function(){
                if(scope.rowData&&scope.rowParent.LookupCache&&scope.rowParent.LookupCache[scope.rowData.Id]&&scope.rowParent.LookupCache[scope.rowData.Id][scope.rowMetadata.relationshipName])
                    return scope.rowParent.LookupCache[scope.rowData.Id][scope.rowMetadata.relationshipName]
                    },function(){
                        if(scope.rowData&&scope.rowParent.LookupCache&&scope.rowParent.LookupCache[scope.rowData.Id]&&scope.rowParent.LookupCache[scope.rowData.Id][scope.rowMetadata.relationshipName])
                            scope.field.actual=scope.field.value=scope.rowParent.LookupCache[scope.rowData.Id][scope.rowMetadata.relationshipName]
                            })
            
        })
        app.controller("BOOLEAN",function($scope){
                   var scope=$scope
                   scope.toggleBoolean=function(){
                       //scope.b=scope.b?false:true
                       //scope.update();
                   }
                                   
        })
        app.controller("OPERATIONSELECT",function($scope){
                   $scope.field.actual=false
                                   
        })
        app.controller("OPERATIONEDIT",function($scope,$parse,$uibModal,$document,$rootScope,dataOperation){
                   $scope.save=function(reladedlist,id){
                       console.log(reladedlist,id)
                       dataOperation.save(reladedlist,id,$scope,[reladedlist,$scope.rowParent.parentdata])
                   }
                   $scope.delete=function(reladedlist,id){
                       console.log(reladedlist,id)
                       dataOperation.delete(reladedlist,id,$scope,[reladedlist,$scope.rowParent.parentdata])
                   }
                                   
        })
        
        app.run(function ($templateCache,$salesforceApiForVf,SESSION_ID,PRM_PREFIX){
          if (!Array.prototype.forEach) {
              Array.prototype.forEach = function(fn, scope) {
                  for(var i = 0, len = this.length; i < len; ++i) {
                      fn.call(scope, this[i], i, this);
                  }
              }
          }
          NodeList.prototype.forEach = Array.prototype.forEach;
          document.querySelectorAll('template[type="text/ng-template"]').forEach(function(v){
               $templateCache.put(v.getAttribute('Id'),v.innerHTML)
          })
          document.querySelectorAll('script[type="text/ng-template"]').forEach(function(v){
               $templateCache.put(v.getAttribute('Id'),v.innerHTML)
          })
          $salesforceApiForVf.org={}
          $salesforceApiForVf.org['access_token']=SESSION_ID
          $salesforceApiForVf.org['instance_url']='https://'+window.location.hostname+PRM_PREFIX||'';
        })  
        
        app.filter('percentage', ['$filter', function ($filter) {
          return function (input, decimals) {
            return $filter('number')(input * 100, decimals) + '%';
          };
        }]);
        app.factory('$salesforceApiForVf',function($q, $rootScope,$http) {
                
                var apiVersion = 'v40.0';
                function toQueryString(obj) {
                    var parts = [],
                        i;
                    for (i in obj) {
                        if (obj.hasOwnProperty(i)) {
                            parts.push(encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]));
                        }
                    }
                    return parts.join("&");
                }
                
            
                function nextRecords(org,result,deferred) {
                    
                    return request({
                        url: org.instance_url+result.data.nextRecordsUrl,
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org,result,deferred);
        
                }
                
                function query(org,soql) {
                    return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/query?q='+encodeURIComponent(soql),
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org);
        
                }
                
                function search(org,soql) {
                    return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/search?q='+encodeURIComponent(soql),
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org);
        
                }
                
                function getSearchLayout(org,objects) {
                    return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/search/layout/?q='+objects,
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org);
        
                }
                
            	function composite(org,compositeObject){
                    var compositeRequest=[]
                	if(compositeObject.query){
                        compositeRequest.push(
                    	{
                            url: '/services/data/' + apiVersion + '/query?q='+encodeURIComponent(compositeObject.query.soql),
                            method:'GET',
                            referenceId:compositeObject.query.referenceId
                        })
                           
                    }
                    if(compositeObject.fetchUrl){
                       compositeRequest.push(
                    	{
                            url: compositeObject.fetchUrl.pathplusquery,
                            method:'GET',
                            referenceId:compositeObject.fetchUrl.referenceId
                        })
                    }
                     return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/composite/',
                        method:'POST',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:JSON.stringify({compositeRequest:compositeRequest})
                    },org);
                }
                
                function toolingQuery(org,soql) {
                    return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/tooling/query?q='+encodeURIComponent(soql),
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org);
        
                }
                
                function fetchUrl(org,pathplusquery) {
                    return request({
                        url: org.instance_url+pathplusquery,
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:null
                    },org);
        
                }
            	function fetchUrlBlob(org,pathplusquery) {
                    return request({
                        url: org.instance_url+pathplusquery,
                        method:'GET',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        responseType: "blob",
                        body:null
                    },org);
        
                }
                
                function save(org,sobject,id,body) {
                    return request({
                        url: org.instance_url+'/services/data/' + apiVersion + '/sobjects/'+sobject+'/'+encodeURIComponent(id),
                        method:'PATCH',
                        headers:{"Authorization": "Bearer " + org.access_token},
                        body:body
                    },org);
        
                }
            
                function request(obj,org,prevresult,deferred,entityTypeName) {
                    if(!deferred){
                        deferred = $q.defer();
                        deferred.prevresult=[];
                    }
                    $http({
                      method: obj.method,
                      url: obj.url,
                      headers:obj.headers,
                      data:obj.body,
                      responseType: obj.responseType||""/*,
                      eventHandlers: {
                           progress: function(c) {
                               //console.log('Progress -> ' + c);
                               //console.log(c);
                           }
                       },
                       uploadEventHandlers: {
                           progress: function(e) {
                               //console.log('UploadProgress -> ' + e);
                               //console.log(e);
                           }
                       }*/
                    }).then(function successCallback(result) {
                        
                        if(result.data.done!=undefined&&!result.data.done){
                                                        
                            var incompleteresult=angular.copy(result)
                            incompleteresult.data.records=deferred.prevresult.concat(incompleteresult.data.records)
                            deferred.notify(incompleteresult);
                            
                            deferred.prevresult=deferred.prevresult.concat(result.data.records)
                            parallelRequest(obj,org,deferred,result.data.nextRecordsUrl,result.data.totalSize)
                            //nextRecords(org,result,deferred)
                        }
                        else{
                            if(deferred.prevresult.length>0){
                                result.data.records=deferred.prevresult.concat(result.data.records)
                            }
                            deferred.resolve(result);
                        }    
                    }, function errorCallback(response) {
                        console.log(response)
                        deferred.reject(response);
                    });
                    
                    return deferred.promise;
                }
                function urlCreator(nextUrl,length){
                	var commonurlpart=nextUrl.substr(0,nextUrl.lastIndexOf("-")+1)
                    var batchsize=Number(nextUrl.substr(nextUrl.lastIndexOf("-")+1,nextUrl.length))
                    var noofparalellerequest=length/batchsize
                    var urls=[]
                    for(i=1;i<noofparalellerequest;i++){
                    	urls.push(commonurlpart+i*batchsize)
                    }
                    return urls;
                }
            	function parallelRequest(obj,org,deferred,nextUrl,length) {
                    var urls=urlCreator(nextUrl,length)
                    var requests=[]
                    urls.forEach(function(url){
                        
                        requests.push($http({
                          method: obj.method,
                          url: org.instance_url+url,
                          headers:obj.headers,
                          data:obj.body
                        }))
                    
                    })
                    
                    
                    $q.all(requests).then(function successCallback(results) {
                       var allresultsrecords=deferred.prevresult
                       results.forEach(function(result){
                       		allresultsrecords=allresultsrecords.concat(result.data.records)
                       })
                       results[results.length-1].data.records=allresultsrecords
                       deferred.resolve(results[results.length-1]);   
                    }, function errorCallback(response) {
                        console.log(response)
                        deferred.reject(response);
                        // a1.slice( 0, 2 ).concat( a2 ).concat( a1.slice( 2 ) );
                    });
                    
                }
            
                return {
                    org: {},
                    query: query,
                    search:search,
                    toolingQuery:toolingQuery,
                    fetchUrl:fetchUrl ,
                    fetchUrlBlob:fetchUrlBlob,
                    getSearchLayout:getSearchLayout,
                    composite:composite
                }; 
        })
        app.factory('$salesforceStreamingOLd',function(Sboject){//cometd
            this.init=function(){
                var $jq = jQuery.noConflict();
               
    
                $jq.cometd.subscribe('/u/CodeExectionStatusReport', function(message) {
                        console.log(message)
                        message=JSON.parse(message.data.payload.replace(/\'/g,'"'))
                        
                        console.log(message)
                });
                
            }
            return this.init
        })
        app.factory('$salesforceStreaming',function(){//cometd
            this.cache={}
            var $jq = jQuery.noConflict();
            this.initialize=function(){
            	 $jq.cometd.init({
                       url: window.location.protocol+'//'+window.location.hostname+'/cometd/40.0/',
                       requestHeaders: { Authorization: 'OAuth {!$Api.Session_ID}'}
                });
            }
            this.subscribe=function(channel,callback){	
                $jq.cometd.subscribe(channel, function(message) {
                    	callback(message)
                });
                
            }
            return this
        })
       
        app.factory('FileplaoderUsingWorkers',function(){
            
        	var blob = new Blob([`self.requestFileSystemSync = self.webkitRequestFileSystemSync ||
                                                                 self.requestFileSystemSync;
                                    
                                    function makeRequest(url) {
                                      try {
                                        var xhr = new XMLHttpRequest();
                                        xhr.open('GET', url, false); // Note: synchronous
                                        xhr.responseType = 'arraybuffer';
                                        xhr.send();
                                        return xhr.response;
                                      } catch(e) {
                                        return "XHR Error " + e.toString();
                                      }
                                    }
                                    
                                    function onError(e) {
                                      postMessage('ERROR: ' + e.toString());
                                    }
                                    
                                    onmessage = function(e) {
                                      var data = e.data;
                                    
                                      // Make sure we have the right parameters.
                                      if (!data.fileName || !data.url || !data.type) {
                                        return;
                                      }
                                    
                                      try {
                                        var fs = requestFileSystemSync(TEMPORARY, 1024 * 1024 /*1MB*/);
                                    
                                        postMessage('Got file system.');
                                    
                                        var fileEntry = fs.root.getFile(data.fileName, {create: true});
                                    
                                        postMessage('Got file entry.');
                                    
                                        var arrayBuffer = makeRequest(data.url);
                                        var blob = new Blob([new Uint8Array(arrayBuffer)], {type: data.type});
                                    
                                        try {
                                          postMessage('Begin writing');
                                          fileEntry.createWriter().write(blob);
                                          postMessage('Writing complete');
                                          postMessage(fileEntry.toURL());
                                        } catch (e) {
                                          onError(e);
                                        }
                                    
                                      } catch (e) {
                                        onError(e);
                                      }
                                    };
        
        							
        							function uploadfile =function( files,success, error )
                                    {
                                    
                                         var fd = new FormData();
                                        
                                         var url = 'your web service url';
                                    
                                         /*angular.forEach(files,function(file){
                                         	fd.append('file',file);
                                         });*/
                                    
                                         //sample data
                                         var data ={
                                             "ContentDocumentId" : "069D00000000so2",
                                             "ReasonForChange" : "Marketing materials updated",
                                             "PathOnClient" : "Q1 Sales Brochure.pdf"
                                         }
                                         data={  
                                            "Description" : "Marketing brochure for Q1 2011",
                                            "Keywords" : "marketing,sales,update",
                                            "FolderId" : "005D0000001GiU7",
                                            "Name" : "Marketing Brochure Q1",
                                            "Type" : "json"
                                         }
                                    
                                     	 fd.append("data", JSON.stringify(data));
                                         var oReq = new XMLHttpRequest();
                                        
                                         oReq.onload = ajaxSuccess;
                                         oReq.open("post", "{{url}}");
                                         var boundary = '---------------------------';
                                         boundary += Math.floor(Math.random()*32768);
                                         boundary += Math.floor(Math.random()*32768);
                                         boundary += Math.floor(Math.random()*32768);
                                         oReq.setRequestHeader("Content-Type", 'multipart/form-data; boundary=' + boundary);
                                         
                                         oReq.send(new FormData(fd));
                                             /*$http.post(url, fd, {
                                                      withCredentials : false,
                                                      headers : {
                                                            'Content-Type' : undefined
                                                      },
                                                    transformRequest : angular.identity
                                             })
                                             .success(function(data)
                                             {
                                              console.log(data);
                                             })
                                             .error(function(data)
                                             {
                                              console.log(data);
                                             });*/
                                    }
        						`]);

            // Obtain a blob URL reference to our worker 'file'.
            var blobURL = window.URL.createObjectURL(blob);//If not need//window.URL.revokeObjectURL(blobURL);
            //new Blob([document.querySelector('#worker1').textContent]);///For loading from script
            
            var worker = new Worker(blobURL);
            worker.onmessage = function(e) {
              console.log(e.data)
            };
        	//worker.postMessage(); // Start the worker
        	worker.postMessage({fileName: 'GoogleLogo',
                      url: 'googlelogo.png', type: 'image/png'});
        	return worker;
        
        })
        app.factory('VisualforceRemotingManager',function($q, $rootScope){
            function dispatch(fn, args) {
                fn = (typeof fn == "function") ? fn : window[fn];  // Allow fn to be a function object or the name of a global function
                return fn.apply(Visualforce.remoting.Manager, args || []);  // args is optional, use an empty array by default
            }
 
            return function(argumentArray) {
                
                var deferred = $q.defer();
                dispatch(Visualforce.remoting.Manager.invokeAction,argumentArray)
                return deferred.promise;
            }
        })
        
        app.directive("fixedHead", function($compile){
            var scrollLeft = 0;
            function combine(elements){
              
                angular.element(elements[1]).on('scroll', function(e){
                    //console.log('scrolling')
                    if(e.isTrigger){
                        e.target.scrollLeft = scrollLeft;
                    }else {
                        scrollLeft = e.target.scrollLeft;
                        angular.element(elements[0])[0].scrollLeft=angular.element(elements[1])[0].scrollLeft;
                        
                    }
                });
            }
            return {
                scope: {
                },
                link: function(scope, element, attrs, ngModel){
                    scope.firstheaderwidth=[]
                    combine(element.children('.'+attrs.combineHorizontalScrolls));
                    scope.$watch(
                        function () {
                            this.fixedHeaderwidth=[]
                            this.originaHeaderwidth=[]
                            var fixedHeaderwidth=this.fixedHeaderwidth
                            var originaHeaderwidth=this.originaHeaderwidth
                            element[0].querySelectorAll('[th-type="fixed"]').forEach(function(v){
                                if(v.querySelector('div'))
                                fixedHeaderwidth.push(v.querySelector('div').offsetWidth)
                            })
                            element[0].querySelectorAll('[th-type="original"]').forEach(function(v){
                                if(v.querySelector('div')){
                                	v.querySelector('div').style.height="0px"
                                	originaHeaderwidth.push(v.querySelector('div').offsetWidth)
                                }
                            })
                            return {
                               fixedHeaderwidth: this.fixedHeaderwidth,
                               originaHeaderwidth: this.originaHeaderwidth
                            }
                       },
                       function (newval,oldval) {
                            element[0].querySelectorAll('[th-type="fixed"]').forEach(function(v,k){
                                if(v.querySelector('div'))
                                v.querySelector('div').style.width=newval.originaHeaderwidth[k]+"px"
                            })
                       }, //listener 
                       true //deep watch
                    );
                }
            };
        });
		app.directive('ngEnter', function () {
            return function (scope, element, attrs) {
                element.bind("keydown keypress", function (event) {
                    if(event.which === 13) {
                        scope.$apply(function (){
                            scope.$eval(attrs.ngEnter);
                        });
         
                        event.preventDefault();
                    }
                });
            };
        });
		app.directive('loader', function () {
            return {
                
                templateUrl: 'SVGloader2.html'
            };
        })
        app.directive('setClassWhenAtTop', function ($window) {
            var $win = angular.element($window); // wrap window object as jQuery object
        
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                    var topClass = attrs.setClassWhenAtTop, // get CSS class from directive's attribute value
                        offsetTop = element[0].offsetTop//element[0].getBoundingClientRect().top;//element[0].offsetTop; // get element's top relative to the document
                    if($win[0].pageYOffset >= offsetTop) {
                            element.addClass(topClass);
                           element.removeClass(attrs.relativeclass);
                    }
                    $win.on('scroll', function (e) {
                        if ($win[0].pageYOffset >= offsetTop) {
                            element.addClass(topClass);
                            element.removeClass(attrs.relativeclass);
                        } else {
                            element.addClass(attrs.relativeclass);
                            element.removeClass(topClass);
                        }
                    });
                }
            };
        })

        app.factory('Performancemonitor',function(){
        	return {
                       getWatchers:function(root) {
                          root = angular.element(root || document.documentElement);
                          var watcherCount = 0;
                         
                          function getElemWatchers(element) {
                            var isolateWatchers = getWatchersFromScope(element.data().$isolateScope);
                            var scopeWatchers = getWatchersFromScope(element.data().$scope);
                            var watchers = scopeWatchers.concat(isolateWatchers);
                            angular.forEach(element.children(), function (childElement) {
                              watchers = watchers.concat(getElemWatchers(angular.element(childElement)));
                            });
                            return watchers;
                          }
                          
                          function getWatchersFromScope(scope) {
                            if (scope) {
                              return scope.$$watchers || [];
                            } else {
                              return [];
                            }
                          }
                         
                          return getElemWatchers(root);
                       }
                   }
        })
        app.directive('trackDigests', function trackDigests($rootScope) {
            function link($scope, $element, $attrs) {
                var count = 0;
                function countDigests(newValue, oldValue) {
                    count++;
                    $element[0].innerHTML = '$digests: ' + count;
                }
                $rootScope.$watch(countDigests);
            }
            return {
                restrict: 'EA',
                link: link
            };
        });
})();