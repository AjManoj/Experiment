var fs = require('fs');

function readFiles(dirname, onFileContent, onError) {
  fs.readdir(dirname, function(err, filenames) {
    if (err) {
      onError(err);
      return;
    }
    filenames.forEach(function(filename) {
      fs.readFile(path.resolve(dirname, filename), 'utf-8', function(err, content) {
        if (err) {
          onError(err);
          return;
        }
        onFileContent(filename, content);
      });
    });
  });
}

var data = '';
readFiles('templates/', function(filename, content) {
  console.log(filename)
  if(filename!='alltemplates.html'){
    data+='<script type="text/ng-template" id="'+filename+'">\r\n\t'
    data+=content.split('\n').join('\n\t')+'\r\n'
    data+='</script>\r\n'
  }
  fs.writeFile("templates/alltemplates.html", data, function(err) {
    if(err) {
        return console.log(err);
    }

    console.log("The file was saved!");
    });
}, function(err) {
  throw err;
});


